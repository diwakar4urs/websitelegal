<?php 
/* ------------------------------------------------------------------
[Modeltheme - SHORTCODES]
[Table of contents]
------------------------------------------------------------------ */
include_once( 'mt-ico-drops/mt-icodrops.php' ); # Icodrops
include_once( 'mt-ico-filters/mt-icofilters.php' ); # Icofilters
include_once( 'mt-search-ico/mt-ico-searchform.php' ); # Search
?>